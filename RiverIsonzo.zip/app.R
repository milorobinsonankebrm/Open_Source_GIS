#################################################################
## App.R - Instream Large Wood on the River Isonzo
## Practical 6 for GEOM184 - Open Source GIS
## Created by Diego Panici (d.panici@exeter.ac.uk)
## Date: 27/02/2025
#################################################################

# Load required packages
install.packages("shiny")
install.packages("leaflet")
install.packages("sf")
install.packages("sp")
install.packages("raster")
install.packages("ggplot2")
install.packages("ggiraph")
install.packages("RColorBrewer")
install.packages("terra")
install.packages("leafem")

library(shiny)
library(leaflet)
library(sf)
library(sp)
library(raster)
library(ggplot2)
library(ggiraph)
library(RColorBrewer)
library(leafem)
library(terra)

options(shiny.maxRequestSize = 1000*1024^2) # Increase max file upload size

#################################################################
# Load Data ----
#################################################################

# Read shapefiles
lw_points_google <- st_read("C:/Users/milor/Documents/LW_Google.shp")
river <- st_read("C:/Users/milor/Desktop/temp_MSc_folder/Open_Source_GIS/Part A/RiverIsonzo.shp")
reach <- st_read("C:/Users/milor/Documents/Reach.shp")
bridges <- st_read("C:/Users/milor/Desktop/temp_MSc_folder/Open_Source_GIS/Part A/BridgesIsonzo.shp")
clusters <- st_read("C:/Users/milor/Desktop/temp_MSc_folder/Open_Source_GIS/Part A/layers/Cluster.gpkg")

# Convert spatial data to WGS84 (CRS 4326)
lw_points_google <- st_transform(lw_points_google, crs = 4326)
river <- st_transform(river, crs = 4326)
reach <- st_transform(reach, crs = 4326)
bridges <- st_transform(bridges, crs = 4326)
clusters <- st_transform(clusters, crs = 4326)

# Generate dynamic color palette for clusters
num_clusters <- length(unique(clusters$CLUSTER_ID))
pal_clusters <- colorFactor(palette = colorRampPalette(brewer.pal(12, "Paired"))(num_clusters), domain = clusters$CLUSTER_ID)

# Load heatmap raster data
heatmap <- raster("C:/Users/milor/Desktop/temp_MSc_folder/Open_Source_GIS/Part A/layers/Google_Heatmap.tif")
pal_heatmap <- colorNumeric(palette = "inferno", domain = na.omit(values(heatmap)), na.color = "transparent")

# Load the Buffered Slope raster
buffered_slope <- raster("C:/Users/milor/Desktop/temp_MSc_folder/Open_Source_GIS/Part A/layers/Buffered_Slope.tif")

# Define a custom color palette (transparent below 0.1, light to dark red)
pal_slope <- colorNumeric(
  palette = colorRampPalette(c("#fb7050", "#910012"))(100),  # Gradient from light to dark red
  domain = na.omit(values(buffered_slope)), 
  na.color = "transparent"
)

# Apply transparency for values below 0.1
buffered_slope_transparent <- calc(buffered_slope, function(x) {
  ifelse(x < 0.1, NA, x)  # Convert values below 0.1 to NA (fully transparent)
})

#################################################################
# Define Simple Red Symbols for Large Wood Types ----
#################################################################

# Define custom red icon symbols for each type of Large Wood
lw_icons <- list(
  "single" = makeIcon(iconUrl = "https://upload.wikimedia.org/wikipedia/commons/1/12/Red_circle.svg", iconWidth = 25, iconHeight = 25),
  "jam" = makeIcon(iconUrl = "https://upload.wikimedia.org/wikipedia/commons/5/5c/Red_triangle.svg", iconWidth = 25, iconHeight = 25),
  "blockage single" = makeIcon(iconUrl = "https://upload.wikimedia.org/wikipedia/commons/1/19/Red_square.svg", iconWidth = 25, iconHeight = 25),
  "blockage jam" = makeIcon(iconUrl = "https://upload.wikimedia.org/wikipedia/commons/2/2a/Red_star.svg", iconWidth = 25, iconHeight = 25)
)

# Define default icon (red circle)
default_icon <- lw_icons[["single"]]  # Default is circle

# Function to get appropriate icon based on LW_Type
get_lw_icon <- function(lw_type) {
  lw_type_clean <- tolower(trimws(lw_type))  # Clean text
  
  sapply(lw_type_clean, function(type) {
    if (type %in% names(lw_icons)) {
      lw_icons[[type]]  # Return the appropriate icon
    } else {
      default_icon  # Return default if not found
    }
  }, simplify = FALSE)
}

#################################################################
# Define UI ----
#################################################################

ui <- navbarPage("Instream Large Wood on the River Isonzo", id = 'nav',
                 tabPanel("Map", 
                          div(class="outer",
                              leafletOutput("map", height = "calc(100vh - 70px)")
                          )
                 )
)

#################################################################
# Server ----
#################################################################

server <- function(input, output, session) {
  
  output$map <- renderLeaflet({
    leaflet() %>% 
      setView(lng = 13.533545, lat = 45.850065, zoom = 11.3) %>%
      addProviderTiles("Esri.WorldImagery", group = "Google Earth Imagery") %>%  # Google Earth imagery
      
      # Add River and reach polylines with improved styling
      addPolylines(data = river, color = "blue", weight = 3, opacity = 0.8, group = "River") %>%
      
      # Add Bridges as circle markers with more visible color and larger size
      addCircleMarkers(data = bridges, color = "red", radius = 6, 
                       group = "Bridges", label = ~as.character(Name), 
                       fillOpacity = 0.8) %>%
      
      # Add Large Wood clusters with dynamic coloring, larger markers, and more visible stroke
      addCircleMarkers(data = clusters, fillColor = ~pal_clusters(CLUSTER_ID), color = "black", 
                       weight = 2, radius = 8, stroke = TRUE, fillOpacity = 0.7,
                       popup = ~paste("<b>Cluster ID:</b>", CLUSTER_ID, 
                                      "<br><b>Type:</b>", ifelse(is.na(LW_Type), "No Type Info", LW_Type),
                                      "<br><b>Additional Info:</b>", ifelse(is.na(Extra_Info), "No Extra Info", Extra_Info)), 
                       group = "Large Wood") %>%
      
      # Add Large Wood points with custom red symbols and larger size
      addMarkers(data = lw_points_google, 
                 icon = ~get_lw_icon(LW_Type), 
                 group = "Large Wood Points", 
                 label = ~as.character(LW_Type)) %>%
      
      # Add Heatmap layer with improved opacity for better visibility
      addRasterImage(heatmap, colors = pal_heatmap, opacity = 0.7, group = "Heatmap") %>%
      addImageQuery(heatmap, layerId = "Heatmap", prefix = "Value: ", 
                    digits = 2, position = "bottomright", group = "Heatmap") %>%
      
      # Add Buffered Slope Raster Layer with new layer name
      addRasterImage(buffered_slope_transparent, colors = pal_slope, opacity = 0.7, group = ">0.1 Slope Gradient") %>%
      addImageQuery(buffered_slope_transparent, layerId = ">0.1 Slope Gradient", prefix = "Slope Value: ", 
                    digits = 2, position = "bottomright", group = ">0.1 Slope Gradient") %>%
      
      # Layers Control with the updated Buffered Slope name and all groups included
      addLayersControl(
        baseGroups = c("Google Earth Imagery"),
        overlayGroups = c("River", "Bridges", "Large Wood", "Large Wood Points", "Heatmap", ">0.1 Slope Gradient"),
        options = layersControlOptions(collapsed = FALSE)
      )
  })
}

#################################################################
# Run the Shiny App ----
#################################################################

shinyApp(ui, server)
